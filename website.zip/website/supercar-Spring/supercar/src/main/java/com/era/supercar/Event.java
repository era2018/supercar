package com.era.supercar;

class Event
{
 
    private Long event;

    public Event(long eventId)
    {
       this.event = eventId;
    }

    public Long getEvent()
    {
        return this.event;
    }


}
