$(document).ready(function() {
    $.ajax({
        url: "http://localhost:8080/events"
    }).then(function(data) {
		
		document.getElementById('data').innerHTML = data.toString();
    });
});