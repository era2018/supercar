function loadJSON(callback) {
    var xobj = new XMLHttpRequest();
        xobj.overrideMimeType("application/json");
    xobj.open('GET', 'http://10.171.3.5:300/SuperCar.json', true); // Replace 'my_data' with the path to your file
    xobj.onreadystatechange = function () {
        if (xobj.readyState == 4 && xobj.status == "200") {
            // Required use of an anonymous callback as .open will NOT return a value but simply returns undefined in asynchronous mode
            callback(xobj.responseText);
        }
    };
    xobj.send(null);
}

function update() {
    loadJSON(function(response) {
        response = response.replace("data:", "");
        console.log(response);
        var obj = JSON.parse(response);
        $('.value').text('slider: ' + obj['absolute']);
    });
}

var element = "home";

function view(str) {
    if (str !== element) {
        document.getElementById(element).style.display = "none";
        element = str;
        document.getElementById(element).style.display = "inline";
    }
}

function pdf() {
    alert("This is when a PDF would pop up.");
}

var blah = setInterval(update, 200);