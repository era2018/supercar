//$.getJSON("carText.json", function(json) {console.log(json);})
function loadJSON(file, callback) {   

    var xobj = new XMLHttpRequest();
    xobj.overrideMimeType("numVal");
    xobj.open('GET', file, true); 
    xobj.onreadystatechange = function () {
          if (xobj.readyState == 4 && xobj.status == "200") {
            callback(xobj.responseText);
          }
    };
    xobj.send(null);  
 }

function doThings() {
    loadJSON("numVal.json", function(response) {
        var v = JSON.parse(numVal);
        document.getElementsByID("fileStuff") = v.numVal;
    });
}